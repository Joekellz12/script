# Build the standalone Windows EXE

This folder contains the 2K27 CV visual-timing assistant and a GitHub Actions workflow that builds a Windows `.exe` on a Windows cloud runner. The computer that runs the finished EXE does **not** need Python installed.

## Create the EXE (one-time setup)

1. Sign in to GitHub and create a **new empty repository** named `2k27-auto-green-cv`.
2. Upload the contents of this folder to the repository, including the hidden `.github` folder and its `workflows/build.yml` file. If using the GitHub web uploader, make sure the workflow file is placed at `.github/workflows/build.yml`.
3. Open the repository's **Actions** tab.
4. Select **Build Windows EXE** on the left.
5. Click **Run workflow** and confirm.
6. Wait for the green checkmark. Open the completed workflow run and download the artifact named `2K27_AUTO_GREEN_CV-Windows`.
7. Extract the downloaded artifact. It contains `2K27_AUTO_GREEN_CV.exe`.

## On the Xbox gaming PC

1. Copy `2K27_AUTO_GREEN_CV.exe` to a folder.
2. Double-click it. No Python or pip installation is required.
3. Connect the capture card, or open Xbox Remote Play first and select Remote Play mode in the app.

Windows may show a SmartScreen warning because this is an unsigned, personally built executable. Only run the file you built from this source repository.

## Notes

- The EXE is built for 64-bit Windows.
- The app is a visual timing assistant. It detects generic visual changes and does not guarantee detection of NBA 2K27's green window or automate controller input.
- If the GitHub Actions build fails, open the failed run and share the error log.
