# 2K27 AUTO GREEN CV — Visual Timing Assistant

A Windows desktop visual analyzer for Xbox gameplay. It supports:
- USB HDMI capture cards through OpenCV/DirectShow.
- Xbox Remote Play by analyzing the monitor where the Remote Play window is displayed.
- A live preview, motion/brightness-change candidate events, adjustable thresholds, timing offset, and saved settings.

## Important limitations
This is a **visual timing assistant**, not a true NBA 2K27 shot-release detector. The generic motion/brightness detector flags visual changes that may include animations, menus, camera movement, and effects. It must be calibrated and tested against your specific jump shot. It does not know the game's green window and does not press/release controller buttons. With the controller wired directly to Xbox, this PC app cannot send controller input through that cable.

## Setup (Windows 10/11)
1. Install Python 3.10 or newer from python.org. During installation, enable **Add Python to PATH**.
2. Extract this ZIP to a normal folder.
3. Open Command Prompt in that folder.
4. Run:
   ```bat
   py -m pip install -r requirements.txt
   ```
5. Connect the capture card to the PC over USB 3.0. Connect Xbox HDMI OUT to the card HDMI IN. If the card has HDMI OUT/pass-through, connect it to your TV/monitor.
6. Run:
   ```bat
   py main.py
   ```

## Capture card mode
- Choose **Capture Card**.
- Start with device index `0`. If no video appears, stop and try `1`, then `2`.
- Some generic cards expose 1080p30 or 1080p60 even when advertised as 4K. The app uses the mode the device actually supplies.

## Xbox Remote Play mode
- Open the official Xbox Remote Play session on the PC first.
- In the app choose **Xbox Remote Play (screen capture)**.
- Select the monitor number containing the Remote Play video. `1` is usually the primary display.
- The app captures that monitor. Put the Remote Play window on the selected display and keep the gameplay visible.

## Tuning
- Motion threshold: lower values flag more visual changes; higher values reduce false positives.
- Brightness-change threshold: sensitivity to sudden overall brightness changes.
- Timing offset: a note for your manual timing experiments only; it does not delay or automate a controller action.
- Use the same camera angle, shot animation, and display setup while calibrating.

## Troubleshooting
- Black screen: check HDMI IN/OUT direction, USB 3.0 port, card device index, and whether another app is using the card.
- No capture device: install any driver supplied by the card maker, then reconnect it.
- Remote Play black screen: move the Remote Play window to the selected monitor and check Windows display capture permissions.
- Slow preview: reduce the capture resolution in the capture-card properties or close other video apps.

## Files
- `main.py` — app and CV loop
- `config.json` — created when settings are saved
- `requirements.txt` — Python dependencies
